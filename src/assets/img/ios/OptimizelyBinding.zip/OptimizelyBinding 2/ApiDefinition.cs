﻿using System;
using System.Drawing;

using MonoTouch.ObjCRuntime;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.CoreGraphics;

namespace Optimizely
{
	[BaseType(typeof(UIView))]
	[Category]
	public interface Optimizely_UIView 
	{
		[Export("optimizelyId")]
		string GetOptimizelyId();

		[Export("setOptimizelyId:")]
		void SetOptimizelyId(string id);
	}

	[BaseType (typeof (NSObject))]
	public partial interface Optimizely
	{
		[Static, Export ("sharedInstance")]
		Optimizely SharedInstance { get; }

		[Static, Export ("startOptimizelyWithAPIToken:launchOptions:")]
		void StartWithAPIToken(string token, [NullAllowed] NSDictionary launchOptions);

		[Static, Export ("handleOpenURL:")]
		bool HandleOpenUrl(NSUrl url);

		[Static, Export ("stringForKey:")]
		string StringForKey(OptimizelyVariableKey key);

		[Static, Export ("colorForKey:")]
		UIColor ColorForKey(OptimizelyVariableKey key);

		[Static, Export ("numberForKey:")]
		NSNumber NumberForKey(OptimizelyVariableKey key);

		[Static, Export ("pointForKey:")]
		PointF PointForKey(OptimizelyVariableKey key);

		[Static, Export ("sizeForKey:")]
		SizeF SizeForKey(OptimizelyVariableKey key);

		[Static, Export ("rectForKey:")]
		RectangleF RectForKey(OptimizelyVariableKey key);

		[Static, Export ("boolForKey:")]
		bool BoolForKey(OptimizelyVariableKey key);

		[Static, Export ("preregisterVariableKey:")]
		void Preregister(OptimizelyVariableKey key);

		[Export ("verboseLogging")]
		bool VerboseLogging { get; set; }

		[Export ("networkTimeout")]
		double NetworkTimeout { get; set; }
	}

	[BaseType (typeof (NSObject))]
	public interface OptimizelyVariableKey
	{
		[Export("key")]
		string Key { get; }

		[Export("defaultValue")]
		NSObject DefaultValue { get; }

		[Export("type")]
		string Type { get; }

		[Static, Export("optimizelyKeyWithKey:defaultNSString:")]
		OptimizelyVariableKey Create(string key, string defaultValue);

		[Static, Export("optimizelyKeyWithKey:defaultUIColor:")]
		OptimizelyVariableKey Create(string key, UIColor defaultValue);

		[Static, Export("optimizelyKeyWithKey:defaultNSNumber:")]
		OptimizelyVariableKey Create(string key, NSNumber defaultValue);

		[Static, Export("optimizelyKeyWithKey:defaultCGPoint:")]
		OptimizelyVariableKey Create(string key, PointF defaultValue);

		[Static, Export("optimizelyKeyWithKey:defaultCGSize:")]
		OptimizelyVariableKey Create(string key, SizeF defaultValue);

		[Static, Export("optimizelyKeyWithKey:defaultCGRect:")]
		OptimizelyVariableKey Create(string key, RectangleF defaultValue);

		[Static, Export("optimizelyKeyWithKey:defaultBOOL:")]
		OptimizelyVariableKey Create(string key, bool defaultValue);
	}
}

