using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("Optimizely", 
	LinkTarget.ArmV7 | LinkTarget.ArmV7s | LinkTarget.Simulator, 
	ForceLoad = true, 
	Frameworks="CFNetwork Foundation Security SystemConfiguration UIKit",
	LinkerFlags = "-ObjC -licucore -lsqlite3"
	)]
